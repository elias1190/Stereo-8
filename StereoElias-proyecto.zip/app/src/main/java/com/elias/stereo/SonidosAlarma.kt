package com.elias.stereo

import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper

// Sonidos de la alarma de velocidad, generados por la app (no usan archivos)
object SonidosAlarma {

    const val TASA = 22050

    val NOMBRES: Array<String> = arrayOf(
        "Pitido doble",
        "Sirena",
        "Alerta rápida",
        "Campana",
        "Grave",
        "Bocina",
        "Radar"
    )

    private val manejador = Handler(Looper.getMainLooper())

    private fun muestras(ms: Int): Int = TASA * ms / 1000

    // Agrega un tono (que puede subir o bajar de frecuencia) en la posición indicada
    private fun poner(
        datos: ShortArray,
        desdeMs: Int,
        durMs: Int,
        frecIni: Double,
        frecFin: Double,
        cuadrada: Boolean,
        amplitud: Double,
        decae: Boolean
    ) {
        val desde = muestras(desdeMs)
        val total = muestras(durMs)
        val borde = muestras(4)
        var fase = 0.0
        for (k in 0 until total) {
            if (desde + k >= datos.size) break
            val t = k.toDouble() / total
            val frecuencia = frecIni + (frecFin - frecIni) * t
            fase += 2.0 * Math.PI * frecuencia / TASA
            val onda = if (cuadrada) {
                if (Math.sin(fase) >= 0.0) 1.0 else -1.0
            } else {
                Math.sin(fase)
            }
            var envolvente = 1.0
            if (k < borde) envolvente = k.toDouble() / borde
            if (total - k < borde) envolvente = minOf(envolvente, (total - k).toDouble() / borde)
            if (decae) envolvente *= Math.exp(-3.5 * t)
            val valor = (onda * envolvente * amplitud * 32000.0).toInt()
            val suma = datos[desde + k] + valor
            datos[desde + k] = suma.coerceIn(-32768, 32767).toShort()
        }
    }

    fun generar(indice: Int): ShortArray {
        return when (indice) {
            1 -> {
                // Sirena: sube y baja
                val d = ShortArray(muestras(1300))
                poner(d, 0, 650, 600.0, 1200.0, false, 1.0, false)
                poner(d, 650, 650, 1200.0, 600.0, false, 1.0, false)
                d
            }
            2 -> {
                // Alerta rápida: tres pitidos cortos
                val d = ShortArray(muestras(700))
                for (i in 0 until 3) poner(d, i * 220, 130, 1500.0, 1500.0, true, 1.0, false)
                d
            }
            3 -> {
                // Campana: dos golpes que se apagan
                val d = ShortArray(muestras(1300))
                for (inicio in intArrayOf(0, 500)) {
                    poner(d, inicio, 750, 880.0, 880.0, false, 0.55, true)
                    poner(d, inicio, 750, 1320.0, 1320.0, false, 0.35, true)
                }
                d
            }
            4 -> {
                // Grave: dos pulsos bajos
                val d = ShortArray(muestras(1000))
                poner(d, 0, 400, 420.0, 420.0, true, 1.0, false)
                poner(d, 500, 400, 420.0, 420.0, true, 1.0, false)
                d
            }
            5 -> {
                // Bocina: dos tonos juntos
                val d = ShortArray(muestras(900))
                poner(d, 0, 800, 420.0, 420.0, true, 0.5, false)
                poner(d, 0, 800, 530.0, 530.0, true, 0.5, false)
                d
            }
            6 -> {
                // Radar: tres barridos que suben
                val d = ShortArray(muestras(900))
                for (i in 0 until 3) poner(d, i * 300, 200, 800.0, 1500.0, false, 1.0, false)
                d
            }
            else -> {
                // Pitido doble
                val d = ShortArray(muestras(700))
                poner(d, 0, 250, 1000.0, 1000.0, true, 1.0, false)
                poner(d, 350, 250, 1000.0, 1000.0, true, 1.0, false)
                d
            }
        }
    }

    // La pista de audio se crea solo cuando suena y se libera enseguida
    fun reproducir(indice: Int, volumen: Int) {
        try {
            val datos = generar(indice)
            val pista = AudioTrack(
                AudioManager.STREAM_MUSIC,
                TASA,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                datos.size * 2,
                AudioTrack.MODE_STATIC
            )
            pista.write(datos, 0, datos.size)
            pista.setVolume(volumen.coerceIn(0, 100) / 100f)
            pista.play()
            val espera = datos.size * 1000L / TASA + 400L
            manejador.postDelayed({
                try {
                    pista.stop()
                    pista.release()
                } catch (e: Exception) {
                }
            }, espera)
        } catch (e: Exception) {
            // sin sonido: no pasa nada
        }
    }
}
