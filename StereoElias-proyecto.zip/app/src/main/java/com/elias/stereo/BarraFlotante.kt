package com.elias.stereo

import android.content.ComponentName
import android.content.Context
import android.graphics.PixelFormat
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageButton
import android.widget.TextView
import kotlin.math.abs

// Barra de música que aparece sobre otras apps (por ejemplo Sygic) mientras suena música
class BarraFlotante(private val contexto: Context) {

    private val ventanas = contexto.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val densidad = contexto.resources.displayMetrics.density

    private var raiz: View? = null
    private var parametros: WindowManager.LayoutParams? = null
    private var barra: View? = null
    private var bola: View? = null
    private var titulo: TextView? = null
    private var play: ImageButton? = null

    private var controlador: MediaController? = null
    private var expandida = true
    private var ultimaAccion = 0L

    private val ciclo = object : Runnable {
        override fun run() {
            try {
                actualizar()
            } catch (e: Exception) {
            }
            handler.postDelayed(this, 1000L)
        }
    }

    fun iniciar() {
        handler.post(ciclo)
    }

    fun detener() {
        handler.removeCallbacks(ciclo)
        quitar()
    }

    private fun dp(valor: Int): Int = (valor * densidad).toInt()

    private fun puedeDibujar(): Boolean {
        return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(contexto)
    }

    private fun escuchaActiva(): Boolean {
        val lista = Settings.Secure.getString(contexto.contentResolver, "enabled_notification_listeners")
        return lista != null && lista.contains(contexto.packageName)
    }

    private fun buscarControlador(): MediaController? {
        return try {
            val gestor = contexto.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val sesiones = gestor.getActiveSessions(ComponentName(contexto, MusicListener::class.java))
            sesiones.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
                ?: sesiones.firstOrNull()
        } catch (e: Exception) {
            null
        }
    }

    private fun actualizar() {
        if (!puedeDibujar() || !escuchaActiva() || Estado.pantallaPropia) {
            quitar()
            return
        }
        val c = buscarControlador()
        controlador = c
        if (c == null) {
            quitar()
            return
        }
        mostrar()

        val datos = c.metadata
        val nombre = datos?.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: datos?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
            ?: "Música"
        titulo?.text = nombre
        val sonando = c.playbackState?.state == PlaybackState.STATE_PLAYING
        play?.setImageResource(if (sonando) R.drawable.ic_pause else R.drawable.ic_play)

        // Se achica sola si no la tocas
        if (expandida && SystemClock.elapsedRealtime() - ultimaAccion > 8000L) {
            cambiarTamano(false)
        }
    }

    private fun mostrar() {
        if (raiz != null) return
        val vista = LayoutInflater.from(contexto).inflate(R.layout.barra_flotante, null)
        raiz = vista
        barra = vista.findViewById<View>(R.id.barra)
        bola = vista.findViewById<View>(R.id.bola)
        titulo = vista.findViewById<TextView>(R.id.barraTitulo)
        play = vista.findViewById<ImageButton>(R.id.barraPlay)

        vista.findViewById<ImageButton>(R.id.barraPrev).setOnClickListener {
            tocado()
            controlador?.transportControls?.skipToPrevious()
        }
        vista.findViewById<ImageButton>(R.id.barraNext).setOnClickListener {
            tocado()
            controlador?.transportControls?.skipToNext()
        }
        play?.setOnClickListener {
            tocado()
            val c = controlador
            if (c != null) {
                if (c.playbackState?.state == PlaybackState.STATE_PLAYING) {
                    c.transportControls.pause()
                } else {
                    c.transportControls.play()
                }
            }
        }
        vista.findViewById<ImageButton>(R.id.barraAchicar).setOnClickListener {
            cambiarTamano(false)
        }

        val tipo = if (Build.VERSION.SDK_INT >= 26) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            WindowManager.LayoutParams.TYPE_PHONE
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            tipo,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        val ajustes = contexto.getSharedPreferences("ajustes", Context.MODE_PRIVATE)
        val pantalla = contexto.resources.displayMetrics
        lp.x = ajustes.getInt("barra_x", dp(160)).coerceIn(0, maxOf(0, pantalla.widthPixels - dp(120)))
        lp.y = ajustes.getInt("barra_y", pantalla.heightPixels - dp(150))
            .coerceIn(0, maxOf(0, pantalla.heightPixels - dp(80)))
        parametros = lp

        arrastrable(vista.findViewById<View>(R.id.agarre), null)
        arrastrable(vista.findViewById<View>(R.id.bola)) { cambiarTamano(true) }

        expandida = true
        ultimaAccion = SystemClock.elapsedRealtime()
        try {
            ventanas.addView(vista, lp)
        } catch (e: Exception) {
            raiz = null
        }
    }

    private fun quitar() {
        val vista = raiz ?: return
        try {
            ventanas.removeView(vista)
        } catch (e: Exception) {
        }
        raiz = null
        parametros = null
    }

    private fun tocado() {
        ultimaAccion = SystemClock.elapsedRealtime()
    }

    private fun cambiarTamano(grande: Boolean) {
        expandida = grande
        ultimaAccion = SystemClock.elapsedRealtime()
        barra?.visibility = if (grande) View.VISIBLE else View.GONE
        bola?.visibility = if (grande) View.GONE else View.VISIBLE
    }

    // Permite mover la barra arrastrando; si solo se toca, ejecuta alToque
    private fun arrastrable(objetivo: View, alToque: (() -> Unit)?) {
        var inicioX = 0
        var inicioY = 0
        var toqueX = 0f
        var toqueY = 0f
        var movio = false
        objetivo.setOnTouchListener { _, evento ->
            val lp = parametros
            if (lp == null) {
                false
            } else {
                when (evento.action) {
                    MotionEvent.ACTION_DOWN -> {
                        inicioX = lp.x
                        inicioY = lp.y
                        toqueX = evento.rawX
                        toqueY = evento.rawY
                        movio = false
                        tocado()
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (evento.rawX - toqueX).toInt()
                        val dy = (evento.rawY - toqueY).toInt()
                        if (abs(dx) > 8 || abs(dy) > 8) movio = true
                        lp.x = inicioX + dx
                        lp.y = inicioY + dy
                        val vista = raiz
                        if (vista != null) {
                            try {
                                ventanas.updateViewLayout(vista, lp)
                            } catch (e: Exception) {
                            }
                        }
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (movio) {
                            contexto.getSharedPreferences("ajustes", Context.MODE_PRIVATE)
                                .edit()
                                .putInt("barra_x", lp.x)
                                .putInt("barra_y", lp.y)
                                .apply()
                        } else {
                            alToque?.invoke()
                        }
                        true
                    }
                    else -> false
                }
            }
        }
    }
}
