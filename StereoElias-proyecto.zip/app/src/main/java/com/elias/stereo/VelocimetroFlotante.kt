package com.elias.stereo

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView

// Velocímetro que se ve sobre cualquier app (por ejemplo Sygic). Se puede arrastrar.
class VelocimetroFlotante(private val contexto: Context) {

    private val ventanas = contexto.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val densidad = contexto.resources.displayMetrics.density

    private var raiz: View? = null
    private var parametros: WindowManager.LayoutParams? = null
    private var numero: TextView? = null
    private var limite: TextView? = null

    private val ciclo = object : Runnable {
        override fun run() {
            try {
                actualizar()
            } catch (e: Exception) {
            }
            handler.postDelayed(this, 500L)
        }
    }

    fun iniciar() {
        handler.post(ciclo)
    }

    fun detener() {
        handler.removeCallbacks(ciclo)
        quitar()
    }

    private fun dp(valor: Int): Int = (valor * densidad).toInt()

    private fun puedeDibujar(): Boolean {
        return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(contexto)
    }

    private fun actualizar() {
        val ajustes = contexto.getSharedPreferences("ajustes", Context.MODE_PRIVATE)
        val activo = ajustes.getBoolean("vel_flotante", true)
        if (!activo || !puedeDibujar() || Estado.pantallaPrincipal || !Estado.gpsActivo) {
            quitar()
            return
        }
        mostrar()
        val ahora = SystemClock.elapsedRealtime()
        val conSenal = ahora - Estado.ultimaMedicion < 5000L
        numero?.text = if (conSenal) Estado.velocidad.toString() else "--"
        numero?.setTextColor(
            if (conSenal && Estado.excedido) Color.parseColor("#FF3B30") else Color.WHITE
        )
        limite?.text = "Límite " + ajustes.getInt("limite", 60)
    }

    private fun mostrar() {
        if (raiz != null) return
        val vista = LayoutInflater.from(contexto).inflate(R.layout.velocimetro_flotante, null)
        raiz = vista
        Tema.aplicar(vista, contexto)
        numero = vista.findViewById<TextView>(R.id.velNumero)
        limite = vista.findViewById<TextView>(R.id.velLimite)

        val tipo = if (Build.VERSION.SDK_INT >= 26) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            WindowManager.LayoutParams.TYPE_PHONE
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            tipo,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        val ajustes = contexto.getSharedPreferences("ajustes", Context.MODE_PRIVATE)
        val pantalla = contexto.resources.displayMetrics
        lp.x = ajustes.getInt("vel_x", pantalla.widthPixels - dp(160))
            .coerceIn(0, maxOf(0, pantalla.widthPixels - dp(100)))
        lp.y = ajustes.getInt("vel_y", dp(70))
            .coerceIn(0, maxOf(0, pantalla.heightPixels - dp(100)))
        parametros = lp

        var inicioX = 0
        var inicioY = 0
        var toqueX = 0f
        var toqueY = 0f
        vista.setOnTouchListener { _, evento ->
            val actual = parametros
            if (actual == null) {
                false
            } else {
                when (evento.action) {
                    MotionEvent.ACTION_DOWN -> {
                        inicioX = actual.x
                        inicioY = actual.y
                        toqueX = evento.rawX
                        toqueY = evento.rawY
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        actual.x = inicioX + (evento.rawX - toqueX).toInt()
                        actual.y = inicioY + (evento.rawY - toqueY).toInt()
                        val v = raiz
                        if (v != null) {
                            try {
                                ventanas.updateViewLayout(v, actual)
                            } catch (e: Exception) {
                            }
                        }
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        contexto.getSharedPreferences("ajustes", Context.MODE_PRIVATE)
                            .edit()
                            .putInt("vel_x", actual.x)
                            .putInt("vel_y", actual.y)
                            .apply()
                        true
                    }
                    else -> false
                }
            }
        }
        try {
            ventanas.addView(vista, lp)
        } catch (e: Exception) {
            raiz = null
        }
    }

    private fun quitar() {
        val vista = raiz ?: return
        try {
            ventanas.removeView(vista)
        } catch (e: Exception) {
        }
        raiz = null
        parametros = null
    }
}
