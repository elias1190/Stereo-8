package com.elias.stereo

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.IBinder
import android.os.SystemClock

class SpeedService : Service(), LocationListener {

    private var manager: LocationManager? = null
    private var barra: BarraFlotante? = null
    private var velocimetro: VelocimetroFlotante? = null
    private val handler = Handler(Looper.getMainLooper())
    private var anterior: Location? = null
    private var ultimoAviso = 0L
    private var estabaExcedido = false
    private var ultimoGuardado = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        iniciarEnPrimerPlano()
        Estado.cargar(this)
        manager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        barra = BarraFlotante(this)
        barra?.iniciar()
        velocimetro = VelocimetroFlotante(this)
        velocimetro?.iniciar()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        pedirUbicacion()
        return START_STICKY
    }

    @Suppress("MissingPermission")
    private fun pedirUbicacion() {
        val lm = manager ?: return
        try {
            lm.removeUpdates(this)
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this)
            Estado.gpsActivo = true
        } catch (e: Exception) {
            Estado.gpsActivo = false
        }
    }

    private fun iniciarEnPrimerPlano() {
        val canal = "velocimetro"
        val builder: Notification.Builder
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel(canal, "Velocímetro", NotificationManager.IMPORTANCE_LOW)
            )
            builder = Notification.Builder(this, canal)
        } else {
            builder = Notification.Builder(this)
        }
        val aviso = builder
            .setContentTitle("Velocímetro activo")
            .setContentText("Midiendo la velocidad con el GPS")
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .build()
        startForeground(1, aviso)
    }

    override fun onLocationChanged(location: Location) {
        val kmh = if (location.hasSpeed()) location.speed * 3.6f else 0f
        val v = if (kmh < 2f) 0 else Math.round(kmh)
        Estado.velocidad = v
        Estado.latitud = location.latitude
        Estado.longitud = location.longitude

        val ahora = SystemClock.elapsedRealtime()
        val previa = anterior
        val buenaPrecision = !location.hasAccuracy() || location.accuracy < 40f
        if (previa != null && v > 0 && buenaPrecision) {
            val metros = previa.distanceTo(location).toDouble()
            if (metros < 500.0) {
                Estado.viajeMetros += metros
                Estado.gncMetros += metros
            }
            val dt = ahora - Estado.ultimaMedicion
            if (dt > 0L && dt < 5000L) {
                Estado.viajeMs += dt
            }
        }
        if (v > Estado.velMax) Estado.velMax = v
        anterior = location
        Estado.ultimaMedicion = ahora

        if (ahora - ultimoGuardado > 5000L) {
            ultimoGuardado = ahora
            Estado.guardarGnc(this)
        }
        controlarAlarma()
    }

    private fun controlarAlarma() {
        val prefs = getSharedPreferences("ajustes", Context.MODE_PRIVATE)
        val activa = prefs.getBoolean("alarma", true)
        val limite = prefs.getInt("limite", 60)
        val intervalo = prefs.getInt("alarma_intervalo", 10)
        val excede = Estado.velocidad > limite
        Estado.excedido = excede
        if (activa && excede) {
            val ahora = SystemClock.elapsedRealtime()
            if (!estabaExcedido) {
                // Recién pasó el límite: avisa enseguida
                ultimoAviso = ahora
                sonarPitido()
            } else if (intervalo > 0 && ahora - ultimoAviso >= intervalo * 1000L) {
                ultimoAviso = ahora
                sonarPitido()
            }
        }
        estabaExcedido = excede
    }

    private fun sonarPitido() {
        val prefs = getSharedPreferences("ajustes", Context.MODE_PRIVATE)
        SonidosAlarma.reproducir(prefs.getInt("alarma_sonido", 0), prefs.getInt("alarma_volumen", 100))
    }

    override fun onProviderEnabled(provider: String) {}

    override fun onProviderDisabled(provider: String) {}

    @Deprecated("Deprecated in Java")
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}

    override fun onDestroy() {
        manager?.removeUpdates(this)
        barra?.detener()
        velocimetro?.detener()
        handler.removeCallbacksAndMessages(null)
        Estado.guardarGnc(this)
        Estado.gpsActivo = false
        super.onDestroy()
    }
}
