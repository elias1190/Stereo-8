package com.elias.stereo

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.os.SystemClock

class SpeedService : Service(), LocationListener {

    private var manager: LocationManager? = null
    private var tono: ToneGenerator? = null
    private var ultimoAviso = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        iniciarEnPrimerPlano()
        manager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        tono = try {
            ToneGenerator(AudioManager.STREAM_MUSIC, 100)
        } catch (e: Exception) {
            null
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        pedirUbicacion()
        return START_STICKY
    }

    @Suppress("MissingPermission")
    private fun pedirUbicacion() {
        val lm = manager ?: return
        try {
            lm.removeUpdates(this)
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this)
            Estado.gpsActivo = true
        } catch (e: Exception) {
            Estado.gpsActivo = false
        }
    }

    private fun iniciarEnPrimerPlano() {
        val canal = "velocimetro"
        val builder: Notification.Builder
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel(canal, "Velocímetro", NotificationManager.IMPORTANCE_LOW)
            )
            builder = Notification.Builder(this, canal)
        } else {
            builder = Notification.Builder(this)
        }
        val aviso = builder
            .setContentTitle("Velocímetro activo")
            .setContentText("Midiendo la velocidad con el GPS")
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .build()
        startForeground(1, aviso)
    }

    override fun onLocationChanged(location: Location) {
        val kmh = if (location.hasSpeed()) location.speed * 3.6f else 0f
        Estado.velocidad = if (kmh < 2f) 0 else Math.round(kmh)
        Estado.ultimaMedicion = SystemClock.elapsedRealtime()
        controlarAlarma()
    }

    private fun controlarAlarma() {
        val prefs = getSharedPreferences("ajustes", Context.MODE_PRIVATE)
        val activa = prefs.getBoolean("alarma", true)
        val limite = prefs.getInt("limite", 60)
        Estado.excedido = Estado.velocidad > limite
        if (activa && Estado.excedido) {
            val ahora = SystemClock.elapsedRealtime()
            if (ahora - ultimoAviso > 3000L) {
                ultimoAviso = ahora
                try {
                    tono?.startTone(ToneGenerator.TONE_PROP_BEEP2, 400)
                } catch (e: Exception) {
                    // sin sonido: no pasa nada
                }
            }
        }
    }

    override fun onProviderEnabled(provider: String) {}

    override fun onProviderDisabled(provider: String) {}

    @Deprecated("Deprecated in Java")
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}

    override fun onDestroy() {
        manager?.removeUpdates(this)
        tono?.release()
        Estado.gpsActivo = false
        super.onDestroy()
    }
}
