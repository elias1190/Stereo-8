package com.elias.stereo

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private val handler = Handler(Looper.getMainLooper())
    private val inicio = SystemClock.elapsedRealtime()
    private var saludo = ""
    private var vozLista = false

    private lateinit var velocidad: TextView
    private lateinit var gps: TextView
    private lateinit var limiteTxt: TextView
    private lateinit var alarmaBtn: Button
    private lateinit var estadoVoz: TextView
    private lateinit var viajeKm: TextView
    private lateinit var viajeTiempo: TextView
    private lateinit var viajeMedia: TextView
    private lateinit var viajeMax: TextView
    private lateinit var gncRestante: TextView
    private lateinit var gncBarra: ProgressBar
    private lateinit var gncDetalle: TextView
    private lateinit var gncAuton: TextView

    private val refrescar = object : Runnable {
        override fun run() {
            actualizarPantalla()
            handler.postDelayed(this, 500L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Estado.cargar(this)

        velocidad = findViewById<TextView>(R.id.velocidad)
        gps = findViewById<TextView>(R.id.gps)
        limiteTxt = findViewById<TextView>(R.id.limite)
        alarmaBtn = findViewById<Button>(R.id.alarma)
        estadoVoz = findViewById<TextView>(R.id.estadoVoz)
        viajeKm = findViewById<TextView>(R.id.viajeKm)
        viajeTiempo = findViewById<TextView>(R.id.viajeTiempo)
        viajeMedia = findViewById<TextView>(R.id.viajeMedia)
        viajeMax = findViewById<TextView>(R.id.viajeMax)
        gncRestante = findViewById<TextView>(R.id.gncRestante)
        gncBarra = findViewById<ProgressBar>(R.id.gncBarra)
        gncDetalle = findViewById<TextView>(R.id.gncDetalle)
        gncAuton = findViewById<TextView>(R.id.gncAuton)

        saludo = saludoPorHora()
        val hola = findViewById<TextView>(R.id.hola)
        hola.text = "Hola, $NOMBRE"
        findViewById<TextView>(R.id.saludo).text = "$saludo · Bienvenido"
        hola.setOnClickListener { repetirSaludo() }

        findViewById<Button>(R.id.menos).setOnClickListener { cambiarLimite(-5) }
        findViewById<Button>(R.id.mas).setOnClickListener { cambiarLimite(5) }
        alarmaBtn.setOnClickListener { alternarAlarma() }

        findViewById<Button>(R.id.reiniciarViaje).setOnClickListener {
            Estado.reiniciarViaje()
            actualizarPantalla()
        }
        findViewById<Button>(R.id.gncMenos).setOnClickListener { cambiarAutonomia(-10) }
        findViewById<Button>(R.id.gncMas).setOnClickListener { cambiarAutonomia(10) }
        findViewById<Button>(R.id.gncCargue).setOnClickListener { confirmarCarga() }

        configurarAcceso(R.id.dockNav, "Navegación", "com.sygic.aura")
        configurarAcceso(R.id.dockRadio, "Radio", null)
        configurarAcceso(R.id.dockMusica, "Música", null)
        findViewById<Button>(R.id.dockApps).setOnClickListener {
            mostrarSelector("Todas las apps") { paquete -> abrirPaquete(paquete) }
        }
        findViewById<Button>(R.id.dockAjustes).setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            } catch (e: Exception) {
            }
        }

        // El saludo suena una sola vez por cada arranque de la app
        if (!yaSaludo) {
            yaSaludo = true
            val grabacion = idGrabacion()
            if (grabacion != 0) {
                reproducirGrabacion(grabacion)
            } else {
                estadoVoz.text = "Iniciando la voz…"
                tts = TextToSpeech(this, this)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        val formato = SimpleDateFormat("EEEE, d 'de' MMMM", Locale("es", "AR"))
        findViewById<TextView>(R.id.fecha).text = formato.format(Date())
        handler.post(refrescar)
        pedirPermisoYArrancar()
    }

    override fun onPause() {
        handler.removeCallbacks(refrescar)
        super.onPause()
    }

    // ---------- Accesos directos ----------

    private fun configurarAcceso(idBoton: Int, nombre: String, predeterminado: String?) {
        val boton = findViewById<Button>(idBoton)
        boton.setOnClickListener { abrirAcceso(nombre, predeterminado) }
        // Mantener apretado para cambiar la app elegida
        boton.setOnLongClickListener {
            elegirApp(nombre)
            true
        }
    }

    private fun abrirAcceso(nombre: String, predeterminado: String?) {
        val guardado = ajustes().getString("acc_$nombre", predeterminado)
        val intento = if (guardado != null) packageManager.getLaunchIntentForPackage(guardado) else null
        if (intento != null) {
            try {
                startActivity(intento)
            } catch (e: Exception) {
            }
        } else {
            elegirApp(nombre)
        }
    }

    private fun elegirApp(nombre: String) {
        mostrarSelector("Elige la app para $nombre") { paquete ->
            ajustes().edit().putString("acc_$nombre", paquete).apply()
            abrirPaquete(paquete)
        }
    }

    private fun abrirPaquete(paquete: String) {
        val intento = packageManager.getLaunchIntentForPackage(paquete) ?: return
        try {
            startActivity(intento)
        } catch (e: Exception) {
        }
    }

    private fun mostrarSelector(titulo: String, alElegir: (String) -> Unit) {
        val gestor = packageManager
        val pedido = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = gestor.queryIntentActivities(pedido, 0)
            .map { Pair(it.loadLabel(gestor).toString(), it.activityInfo.packageName) }
            .filter { it.second != packageName }
            .sortedBy { it.first.lowercase() }
        val nombres = apps.map { it.first }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(titulo)
            .setItems(nombres) { _, posicion -> alElegir(apps[posicion].second) }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ---------- GNC y viaje ----------

    private fun cambiarAutonomia(cambio: Int) {
        val nueva = (ajustes().getInt("gnc_auton", 220) + cambio).coerceIn(50, 600)
        ajustes().edit().putInt("gnc_auton", nueva).apply()
        actualizarPantalla()
    }

    private fun confirmarCarga() {
        AlertDialog.Builder(this)
            .setTitle("¿Cargaste el tubo lleno?")
            .setMessage("Se reinicia la cuenta de kilómetros del GNC.")
            .setPositiveButton("Sí, cargué") { _, _ ->
                Estado.gncMetros = 0.0
                Estado.guardarGnc(this)
                actualizarPantalla()
            }
            .setNegativeButton("No", null)
            .show()
    }

    private fun un(decimal: Double): String {
        return String.format(Locale("es", "AR"), "%.1f", decimal)
    }

    private fun tiempoTexto(ms: Long): String {
        val minutos = ms / 60000L
        val resto = (minutos % 60L).toString().padStart(2, '0')
        return (minutos / 60L).toString() + ":" + resto
    }

    // ---------- Velocímetro ----------

    private fun pedirPermisoYArrancar() {
        if (Estado.gpsActivo) return
        if (Build.VERSION.SDK_INT >= 23 &&
            checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), PEDIDO_UBICACION)
        } else {
            arrancarServicio()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PEDIDO_UBICACION &&
            grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            arrancarServicio()
        }
    }

    private fun arrancarServicio() {
        val intento = Intent(this, SpeedService::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(intento)
        } else {
            startService(intento)
        }
    }

    private fun ajustes() = getSharedPreferences("ajustes", Context.MODE_PRIVATE)

    private fun cambiarLimite(cambio: Int) {
        val nuevo = (ajustes().getInt("limite", 60) + cambio).coerceIn(20, 200)
        ajustes().edit().putInt("limite", nuevo).apply()
        actualizarPantalla()
    }

    private fun alternarAlarma() {
        val activa = ajustes().getBoolean("alarma", true)
        ajustes().edit().putBoolean("alarma", !activa).apply()
        actualizarPantalla()
    }

    private fun actualizarPantalla() {
        val ahora = SystemClock.elapsedRealtime()
        val conSenal = Estado.gpsActivo && ahora - Estado.ultimaMedicion < 5000L
        velocidad.text = if (conSenal) Estado.velocidad.toString() else "--"
        velocidad.setTextColor(
            if (conSenal && Estado.excedido) Color.parseColor("#FF3B30") else Color.WHITE
        )
        gps.text = when {
            !Estado.gpsActivo -> "GPS apagado: falta el permiso de ubicación"
            !conSenal -> "Buscando señal de GPS…"
            else -> "GPS conectado"
        }
        limiteTxt.text = "Límite " + ajustes().getInt("limite", 60)
        alarmaBtn.text = if (ajustes().getBoolean("alarma", true)) "Alarma: sí" else "Alarma: no"

        // Viaje
        val km = Estado.viajeMetros / 1000.0
        viajeKm.text = un(km)
        viajeTiempo.text = tiempoTexto(Estado.viajeMs)
        viajeMedia.text = if (Estado.viajeMs > 0L) {
            Math.round(km / (Estado.viajeMs / 3600000.0)).toString()
        } else {
            "0"
        }
        viajeMax.text = Estado.velMax.toString()

        // GNC
        val autonomia = ajustes().getInt("gnc_auton", 220)
        val recorrido = Estado.gncMetros / 1000.0
        val resta = (autonomia - recorrido).coerceAtLeast(0.0)
        gncRestante.text = Math.round(resta).toString() + " km"
        gncRestante.setTextColor(if (resta <= RESERVA_KM) Color.parseColor("#FF3B30") else Color.WHITE)
        gncBarra.progress = if (autonomia > 0) Math.round(resta / autonomia * 100.0).toInt() else 0
        gncDetalle.text = "Recorridos " + Math.round(recorrido) + " km desde la carga"
        gncAuton.text = "Tubo lleno: $autonomia km"
    }

    // ---------- Saludo ----------

    private fun idGrabacion(): Int {
        val nombre = when (saludo) {
            "Buenos días" -> "saludo_dias"
            "Buenas tardes" -> "saludo_tardes"
            else -> "saludo_noches"
        }
        return resources.getIdentifier(nombre, "raw", packageName)
    }

    private fun reproducirGrabacion(id: Int) {
        try {
            val reproductor = MediaPlayer.create(this, id) ?: return
            reproductor.setOnCompletionListener { it.release() }
            reproductor.start()
            estadoVoz.text = "Saludo grabado"
        } catch (e: Exception) {
        }
    }

    private fun repetirSaludo() {
        val grabacion = idGrabacion()
        if (grabacion != 0) reproducirGrabacion(grabacion) else decirSaludo()
    }

    override fun onInit(status: Int) {
        val voz = tts ?: return
        if (status != TextToSpeech.SUCCESS) {
            estadoVoz.text = "Sin motor de voz"
            return
        }

        var resultado = voz.setLanguage(Locale("es", "AR"))
        if (sinIdioma(resultado)) resultado = voz.setLanguage(Locale("es", "ES"))
        if (sinIdioma(resultado)) resultado = voz.setLanguage(Locale("es"))
        if (sinIdioma(resultado)) {
            estadoVoz.text = "Sin voz en español"
            return
        }

        vozLista = true
        estadoVoz.text = "Voz lista a los " + segundos() + " s"

        voz.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                val texto = "Saludo dicho a los " + segundos() + " s"
                runOnUiThread { estadoVoz.text = texto }
            }

            override fun onDone(utteranceId: String?) {}

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {}
        })

        handler.postDelayed({ decirSaludo() }, ESPERA_MS)
    }

    private fun segundos(): String {
        val s = (SystemClock.elapsedRealtime() - inicio) / 100L
        return (s / 10L).toString() + "." + (s % 10L).toString()
    }

    private fun decirSaludo() {
        if (!vozLista) return
        tts?.speak("$saludo, $NOMBRE", TextToSpeech.QUEUE_FLUSH, null, "saludo")
    }

    private fun sinIdioma(resultado: Int): Boolean {
        return resultado == TextToSpeech.LANG_MISSING_DATA ||
            resultado == TextToSpeech.LANG_NOT_SUPPORTED
    }

    private fun saludoPorHora(): String {
        val hora = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when (hora) {
            in 6..11 -> "Buenos días"
            in 12..19 -> "Buenas tardes"
            else -> "Buenas noches"
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        tts?.shutdown()
        super.onDestroy()
    }

    companion object {
        const val NOMBRE = "Elias"
        const val ESPERA_MS = 300L
        const val PEDIDO_UBICACION = 10
        const val RESERVA_KM = 30.0
        var yaSaludo = false
    }
}
