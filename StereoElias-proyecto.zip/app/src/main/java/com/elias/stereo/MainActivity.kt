package com.elias.stereo

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private val handler = Handler(Looper.getMainLooper())
    private var saludo: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        saludo = saludoPorHora()
        findViewById<TextView>(R.id.hola).text = "Hola, $NOMBRE"
        findViewById<TextView>(R.id.saludo).text = "$saludo · Bienvenido"

        // El saludo por voz suena una sola vez por cada arranque de la app
        if (!yaSaludo) {
            yaSaludo = true
            tts = TextToSpeech(this, this)
        }
    }

    override fun onResume() {
        super.onResume()
        val formato = SimpleDateFormat("EEEE, d 'de' MMMM", Locale("es", "AR"))
        findViewById<TextView>(R.id.fecha).text = formato.format(Date())
    }

    override fun onInit(status: Int) {
        val voz = tts ?: return
        if (status != TextToSpeech.SUCCESS) return

        var resultado = voz.setLanguage(Locale("es", "AR"))
        if (sinIdioma(resultado)) resultado = voz.setLanguage(Locale("es", "ES"))
        if (sinIdioma(resultado)) resultado = voz.setLanguage(Locale("es"))
        if (sinIdioma(resultado)) return

        // Espera unos segundos a que el stereo termine de arrancar
        handler.postDelayed({
            voz.speak("$saludo, $NOMBRE", TextToSpeech.QUEUE_FLUSH, null, "saludo")
        }, ESPERA_MS)
    }

    private fun sinIdioma(resultado: Int): Boolean {
        return resultado == TextToSpeech.LANG_MISSING_DATA ||
            resultado == TextToSpeech.LANG_NOT_SUPPORTED
    }

    private fun saludoPorHora(): String {
        val hora = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when (hora) {
            in 6..11 -> "Buenos días"
            in 12..19 -> "Buenas tardes"
            else -> "Buenas noches"
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        tts?.shutdown()
        super.onDestroy()
    }

    companion object {
        const val NOMBRE = "Elias"
        const val ESPERA_MS = 3000L
        var yaSaludo = false
    }
}
