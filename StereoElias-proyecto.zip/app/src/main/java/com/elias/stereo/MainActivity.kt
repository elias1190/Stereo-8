package com.elias.stereo

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.animation.ObjectAnimator
import android.app.Dialog
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Drawable
import android.media.MediaMetadata
import android.media.MediaPlayer
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.GridView
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ImageButton
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import org.json.JSONObject

class MainActivity : Activity(), TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private val handler = Handler(Looper.getMainLooper())
    private val inicio = SystemClock.elapsedRealtime()
    private var saludo = ""
    private var vozLista = false

    private lateinit var velocidad: TextView
    private lateinit var gps: TextView
    private lateinit var limiteTxt: TextView
    private lateinit var alarmaBtn: Button
    private lateinit var estadoVoz: TextView
    private lateinit var viajeKm: TextView
    private lateinit var viajeTiempo: TextView
    private lateinit var viajeMedia: TextView
    private lateinit var viajeMax: TextView
    private lateinit var gncRestante: TextView
    private lateinit var gncBarra: ProgressBar
    private lateinit var gncDetalle: TextView
    private lateinit var gncAuton: TextView
    private lateinit var musicaTitulo: TextView
    private lateinit var musicaArtista: TextView
    private lateinit var musicaFuente: TextView
    private lateinit var musicaPlay: ImageButton
    private var controlador: MediaController? = null
    private var vuelta = 0
    private var ultimoClima = 0L
    @Volatile private var consultando = false
    private lateinit var climaTemp: TextView
    private lateinit var climaDesc: TextView
    private lateinit var climaExtra: TextView
    private var escuchado: MediaController? = null
    private var cambios = 0

    // Avisos del reproductor: se disparan apenas cambia la canción o el estado
    private val avisos = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) {
            cambios++
            actualizarMusica()
        }

        override fun onPlaybackStateChanged(state: PlaybackState?) {
            actualizarMusica()
        }
    }

    private val refrescar = object : Runnable {
        override fun run() {
            try {
                actualizarPantalla()
                vuelta++
                if (vuelta % 2 == 0) actualizarMusica()
            } catch (e: Exception) {
            }
            handler.postDelayed(this, 500L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Estado.cargar(this)
        Tema.aplicar(findViewById<View>(android.R.id.content), this)

        climaTemp = findViewById<TextView>(R.id.climaTemp)
        climaDesc = findViewById<TextView>(R.id.climaDesc)
        climaExtra = findViewById<TextView>(R.id.climaExtra)

        velocidad = findViewById<TextView>(R.id.velocidad)
        gps = findViewById<TextView>(R.id.gps)
        limiteTxt = findViewById<TextView>(R.id.limite)
        alarmaBtn = findViewById<Button>(R.id.alarma)
        estadoVoz = findViewById<TextView>(R.id.estadoVoz)
        viajeKm = findViewById<TextView>(R.id.viajeKm)
        viajeTiempo = findViewById<TextView>(R.id.viajeTiempo)
        viajeMedia = findViewById<TextView>(R.id.viajeMedia)
        viajeMax = findViewById<TextView>(R.id.viajeMax)
        gncRestante = findViewById<TextView>(R.id.gncRestante)
        gncBarra = findViewById<ProgressBar>(R.id.gncBarra)
        gncDetalle = findViewById<TextView>(R.id.gncDetalle)
        gncAuton = findViewById<TextView>(R.id.gncAuton)

        musicaTitulo = findViewById<TextView>(R.id.musicaTitulo)
        musicaArtista = findViewById<TextView>(R.id.musicaArtista)
        musicaFuente = findViewById<TextView>(R.id.musicaFuente)
        musicaPlay = findViewById<ImageButton>(R.id.musicaPlay)
        val abrirMusica = View.OnClickListener {
            if (!escuchaActiva()) abrirPermisoMusica() else abrirAcceso("Música", null)
        }
        musicaTitulo.setOnClickListener(abrirMusica)
        musicaArtista.setOnClickListener(abrirMusica)
        musicaFuente.setOnClickListener(abrirMusica)
        // Mantener apretado: cambiar la app de música / activar la barra flotante
        musicaTitulo.setOnLongClickListener {
            elegirApp("Música")
            true
        }
        musicaArtista.setOnLongClickListener {
            pedirSuperposicion(true)
            true
        }
        findViewById<ImageButton>(R.id.musicaPrev).setOnClickListener { controlarMusica(-1) }
        musicaPlay.setOnClickListener { controlarMusica(0) }
        findViewById<ImageButton>(R.id.musicaNext).setOnClickListener { controlarMusica(1) }

        // Las luces del auto se encienden con un parpadeo la primera vez
        val luces = findViewById<ImageView>(R.id.fotoLuces)
        if (!lucesEncendidas) {
            lucesEncendidas = true
            luces.alpha = 0f
            val animacion = ObjectAnimator.ofFloat(luces, "alpha", 0f, 0.9f, 0.1f, 1f)
            animacion.duration = 1600L
            animacion.startDelay = 500L
            animacion.start()
        }


        saludo = saludoPorHora()
        val hola = findViewById<TextView>(R.id.hola)
        hola.text = "Hola, $NOMBRE"
        findViewById<TextView>(R.id.saludo).text = "$saludo · Bienvenido"
        hola.setOnClickListener { repetirSaludo() }

        findViewById<Button>(R.id.menos).setOnClickListener { cambiarLimite(-5) }
        findViewById<Button>(R.id.mas).setOnClickListener { cambiarLimite(5) }
        alarmaBtn.setOnClickListener { alternarAlarma() }
        alarmaBtn.setOnLongClickListener {
            startActivity(Intent(this, AlarmaActivity::class.java))
            true
        }

        findViewById<Button>(R.id.reiniciarViaje).setOnClickListener {
            Estado.reiniciarViaje()
            actualizarPantalla()
        }
        findViewById<Button>(R.id.gncMenos).setOnClickListener { cambiarAutonomia(-10) }
        findViewById<Button>(R.id.gncMas).setOnClickListener { cambiarAutonomia(10) }
        findViewById<Button>(R.id.gncCargue).setOnClickListener { confirmarCarga() }

        configurarAcceso(R.id.dockNav, "Navegación", "com.sygic.aura")
        configurarAcceso(R.id.dockRadio, "Radio", "com.acloud.stud.localradio")
        findViewById<Button>(R.id.dockMusica).setOnClickListener {
            startActivity(Intent(this, BluetoothActivity::class.java))
        }
        findViewById<Button>(R.id.dockApps).setOnClickListener {
            mostrarSelector("Todas las apps") { paquete -> abrirPaquete(paquete) }
        }
        findViewById<Button>(R.id.dockAjustes).setOnClickListener { menuAjustes() }

        handler.postDelayed({ if (!isFinishing) pedirSuperposicion(false) }, 6000L)

        // El saludo suena una sola vez por cada arranque de la app
        if (!yaSaludo) {
            yaSaludo = true
            val grabacion = idGrabacion()
            if (grabacion != 0) {
                reproducirGrabacion(grabacion)
            } else {
                estadoVoz.text = "Iniciando la voz…"
                tts = TextToSpeech(this, this)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        val formato = SimpleDateFormat("EEEE, d 'de' MMMM", Locale("es", "AR"))
        findViewById<TextView>(R.id.fecha).text = formato.format(Date())
        handler.post(refrescar)
        Estado.pantallaPropia = true
        pedirPermisoYArrancar()
    }

    override fun onPause() {
        Estado.pantallaPropia = false
        handler.removeCallbacks(refrescar)
        super.onPause()
    }

    // ---------- Accesos directos ----------

    private fun configurarAcceso(idBoton: Int, nombre: String, predeterminado: String?) {
        val boton = findViewById<Button>(idBoton)
        boton.setOnClickListener { abrirAcceso(nombre, predeterminado) }
        // Mantener apretado para cambiar la app elegida
        boton.setOnLongClickListener {
            elegirApp(nombre)
            true
        }
    }

    private fun abrirAcceso(nombre: String, predeterminado: String?) {
        val guardado = ajustes().getString("acc_$nombre", predeterminado)
        val intento = if (guardado != null) packageManager.getLaunchIntentForPackage(guardado) else null
        if (intento != null) {
            try {
                startActivity(intento)
            } catch (e: Exception) {
            }
        } else {
            elegirApp(nombre)
        }
    }

    private fun elegirApp(nombre: String) {
        mostrarSelector("Elige la app para $nombre") { paquete ->
            ajustes().edit().putString("acc_$nombre", paquete).apply()
            abrirPaquete(paquete)
        }
    }

    private fun abrirPaquete(paquete: String) {
        val intento = packageManager.getLaunchIntentForPackage(paquete) ?: return
        try {
            startActivity(intento)
        } catch (e: Exception) {
        }
    }

    private fun mostrarSelector(titulo: String, alElegir: (String) -> Unit) {
        val gestor = packageManager
        val pedido = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = gestor.queryIntentActivities(pedido, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map { AppInfo(it.loadLabel(gestor).toString(), it.activityInfo.packageName, it.loadIcon(gestor)) }
            .sortedBy { it.nombre.lowercase() }

        val dialogo = Dialog(this, android.R.style.Theme_Material_NoActionBar_Fullscreen)
        dialogo.setContentView(R.layout.dialogo_apps)
        Tema.aplicar(dialogo.findViewById<View>(android.R.id.content), this)
        dialogo.findViewById<TextView>(R.id.tituloApps).text = titulo
        dialogo.findViewById<Button>(R.id.cerrarApps).setOnClickListener { dialogo.dismiss() }

        val grilla = dialogo.findViewById<GridView>(R.id.grilla)
        grilla.adapter = object : BaseAdapter() {
            override fun getCount(): Int = apps.size

            override fun getItem(position: Int): Any = apps[position]

            override fun getItemId(position: Int): Long = position.toLong()

            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val vista = convertView ?: layoutInflater.inflate(R.layout.item_app, parent, false)
                val app = apps[position]
                vista.findViewById<ImageView>(R.id.appIcono).setImageDrawable(app.icono)
                vista.findViewById<TextView>(R.id.appNombre).text = app.nombre
                return vista
            }
        }
        grilla.setOnItemClickListener { _, _, posicion, _ ->
            dialogo.dismiss()
            alElegir(apps[posicion].paquete)
        }
        // Mantener apretado una app muestra su nombre técnico
        grilla.setOnItemLongClickListener { _, _, posicion, _ ->
            Toast.makeText(this, apps[posicion].paquete, Toast.LENGTH_LONG).show()
            true
        }
        dialogo.show()
    }

    // ---------- Ajustes y color ----------

    private fun dp(valor: Int): Int = (valor * resources.displayMetrics.density).toInt()

    private fun menuAjustes() {
        val opciones = arrayOf(
            "Color de la interfaz",
            "Barra de música sobre otras apps",
            "Pruebas del stereo (radio, Sygic y voz)",
            "Sonido y volumen de la alarma de velocidad",
            "Ajustes de Android"
        )
        AlertDialog.Builder(this)
            .setTitle("Ajustes")
            .setItems(opciones) { _, posicion ->
                when (posicion) {
                    0 -> elegirColor()
                    1 -> pedirSuperposicion(true)
                    2 -> startActivity(Intent(this, DiagnosticoActivity::class.java))
                    3 -> startActivity(Intent(this, AlarmaActivity::class.java))
                    else -> {
                        try {
                            startActivity(Intent(Settings.ACTION_SETTINGS))
                        } catch (e: Exception) {
                        }
                    }
                }
            }
            .setNegativeButton("Cerrar", null)
            .show()
    }

    private fun elegirColor() {
        val fila = LinearLayout(this)
        fila.orientation = LinearLayout.HORIZONTAL
        fila.gravity = android.view.Gravity.CENTER
        fila.setPadding(dp(8), dp(24), dp(8), dp(12))
        val desplazable = HorizontalScrollView(this)
        desplazable.addView(fila)
        val dialogo = AlertDialog.Builder(this)
            .setTitle("Color de la interfaz")
            .setView(desplazable)
            .setNegativeButton("Cerrar", null)
            .create()
        val elegido = Tema.indice(this)
        for ((i, par) in Tema.PALETA.withIndex()) {
            val muestra = View(this)
            val medidas = LinearLayout.LayoutParams(dp(48), dp(48))
            medidas.setMargins(dp(6), 0, dp(6), 0)
            muestra.layoutParams = medidas
            val circulo = GradientDrawable()
            circulo.shape = GradientDrawable.OVAL
            circulo.setColor(par.second)
            if (i == elegido) circulo.setStroke(dp(4), Color.WHITE)
            muestra.background = circulo
            muestra.contentDescription = par.first
            muestra.setOnClickListener {
                ajustes().edit().putInt("tema", i).apply()
                dialogo.dismiss()
                recreate()
            }
            fila.addView(muestra)
        }
        dialogo.show()
    }

    // ---------- Clima ----------

    private fun descripcionClima(codigo: Int): String {
        return when (codigo) {
            0 -> "Despejado"
            1 -> "Mayormente despejado"
            2 -> "Parcialmente nublado"
            3 -> "Nublado"
            45, 48 -> "Niebla"
            51, 53, 55 -> "Llovizna"
            56, 57 -> "Llovizna helada"
            61, 63, 65 -> "Lluvia"
            66, 67 -> "Lluvia helada"
            71, 73, 75, 77 -> "Nieve"
            80, 81, 82 -> "Chubascos"
            85, 86 -> "Nevadas"
            95, 96, 99 -> "Tormenta"
            else -> "Variable"
        }
    }

    private fun mostrarClima() {
        val sinUbicacion = Estado.latitud == 0.0 && Estado.longitud == 0.0
        if (Estado.climaOk) {
            climaTemp.text = Estado.climaTemp.toString() + "°"
            climaDesc.text = descripcionClima(Estado.climaCodigo)
            climaExtra.text = "máx " + Estado.climaMax + "° · mín " + Estado.climaMin + "° · " +
                Estado.climaHumedad + "% · " + Estado.climaViento + " km/h"
        } else {
            climaTemp.text = "--°"
            climaDesc.text = if (sinUbicacion) "Esperando ubicación" else "Sin datos del clima"
            climaExtra.text = if (sinUbicacion) "" else "Hace falta internet (WiFi o datos del celular)"
        }
    }

    private fun revisarClima() {
        val ahora = SystemClock.elapsedRealtime()
        val espera = if (Estado.climaOk) 30L * 60000L else 60000L
        if (consultando) return
        if (ultimoClima != 0L && ahora - ultimoClima < espera) return
        if (Estado.latitud == 0.0 && Estado.longitud == 0.0) return
        consultando = true
        ultimoClima = ahora
        val lat = Estado.latitud
        val lon = Estado.longitud
        Thread {
            var bien = false
            try {
                val direccion = "https://api.open-meteo.com/v1/forecast?latitude=" + lat + "&longitude=" + lon +
                    "&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m" +
                    "&daily=temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=1"
                val conexion = URL(direccion).openConnection() as HttpURLConnection
                conexion.connectTimeout = 8000
                conexion.readTimeout = 8000
                val texto = conexion.inputStream.bufferedReader().use { it.readText() }
                conexion.disconnect()
                val json = JSONObject(texto)
                val actual = json.getJSONObject("current")
                val diario = json.getJSONObject("daily")
                Estado.climaTemp = Math.round(actual.getDouble("temperature_2m")).toInt()
                Estado.climaHumedad = Math.round(actual.getDouble("relative_humidity_2m")).toInt()
                Estado.climaViento = Math.round(actual.getDouble("wind_speed_10m")).toInt()
                Estado.climaCodigo = actual.getInt("weather_code")
                Estado.climaMax = Math.round(diario.getJSONArray("temperature_2m_max").getDouble(0)).toInt()
                Estado.climaMin = Math.round(diario.getJSONArray("temperature_2m_min").getDouble(0)).toInt()
                bien = true
            } catch (e: Exception) {
                bien = false
            }
            Estado.climaOk = bien
            consultando = false
        }.start()
    }

    // ---------- Barra de música sobre otras apps ----------

    private fun pedirSuperposicion(forzar: Boolean) {
        if (Build.VERSION.SDK_INT < 23) return
        if (Settings.canDrawOverlays(this)) {
            if (forzar) {
                Toast.makeText(this, "La barra flotante ya está activada", Toast.LENGTH_SHORT).show()
            }
            return
        }
        if (!forzar && ajustes().getBoolean("pidio_superposicion", false)) return
        ajustes().edit().putBoolean("pidio_superposicion", true).apply()
        AlertDialog.Builder(this)
            .setTitle("Controles de música sobre otras apps")
            .setMessage("Para ver la barra de música sobre Sygic, activa Mostrar sobre otras apps para Stereo Elias.")
            .setPositiveButton("Activar") { _, _ ->
                try {
                    startActivity(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                    )
                } catch (e: Exception) {
                    Toast.makeText(
                        this,
                        "Busca en Ajustes: Apps, Stereo Elias, Mostrar sobre otras apps",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
            .setNegativeButton("Ahora no", null)
            .show()
    }

    // ---------- Música ----------

    private fun escuchaActiva(): Boolean {
        val lista = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        return lista != null && lista.contains(packageName)
    }

    private fun abrirPermisoMusica() {
        try {
            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        } catch (e: Exception) {
            Toast.makeText(
                this,
                "Entra a Ajustes, busca Acceso a notificaciones y activa Stereo Elias",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun controlarMusica(accion: Int) {
        val c = controlador
        if (c == null) {
            if (!escuchaActiva()) abrirPermisoMusica()
            return
        }
        try {
            when (accion) {
                -1 -> c.transportControls.skipToPrevious()
                1 -> c.transportControls.skipToNext()
                else -> {
                    val estado = c.playbackState?.state
                    if (estado == PlaybackState.STATE_PLAYING) {
                        c.transportControls.pause()
                    } else {
                        c.transportControls.play()
                    }
                }
            }
        } catch (e: Exception) {
        }
        handler.postDelayed({ actualizarMusica() }, 700L)
        handler.postDelayed({ actualizarMusica() }, 2000L)
    }

    private fun actualizarMusica() {
        if (!escuchaActiva()) {
            controlador = null
            musicaTitulo.text = "Falta el permiso de música"
            musicaArtista.text = "Toca aquí para activarlo"
            musicaFuente.text = ""
            musicaPlay.setImageResource(R.drawable.ic_play)
            return
        }
        try {
            val gestor = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            val sesiones = gestor.getActiveSessions(ComponentName(this, MusicListener::class.java))
            controlador = sesiones.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
                ?: sesiones.firstOrNull()
        } catch (e: Exception) {
            controlador = null
        }
        val c = controlador
        if (c == null) {
            musicaTitulo.text = "Sin música activa"
            musicaArtista.text = "Pon música por Bluetooth o en una app"
            musicaFuente.text = ""
            musicaPlay.setImageResource(R.drawable.ic_play)
            return
        }
        try {
            if (escuchado == null || escuchado?.sessionToken != c.sessionToken) {
                escuchado?.unregisterCallback(avisos)
                c.registerCallback(avisos, handler)
                escuchado = c
            }
        } catch (e: Exception) {
        }
        val datos = c.metadata
        val titulo = textoLimpio(datos?.getString(MediaMetadata.METADATA_KEY_TITLE))
            ?: textoLimpio(datos?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE))
        val artista = textoLimpio(datos?.getString(MediaMetadata.METADATA_KEY_ARTIST))
            ?: textoLimpio(datos?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST))
            ?: ""
        musicaTitulo.text = titulo ?: "Sonando (sin título)"
        musicaArtista.text = if (titulo == null) "El celular no envía el título" else artista
        musicaFuente.text = c.packageName + " · avisos: " + cambios
        val sonando = c.playbackState?.state == PlaybackState.STATE_PLAYING
        musicaPlay.setImageResource(if (sonando) R.drawable.ic_pause else R.drawable.ic_play)
    }

    // ---------- GNC y viaje ----------

    private fun cambiarAutonomia(cambio: Int) {
        val nueva = (ajustes().getInt("gnc_auton", 220) + cambio).coerceIn(50, 600)
        ajustes().edit().putInt("gnc_auton", nueva).apply()
        actualizarPantalla()
    }

    private fun confirmarCarga() {
        AlertDialog.Builder(this)
            .setTitle("¿Cargaste el tubo lleno?")
            .setMessage("Se reinicia la cuenta de kilómetros del GNC.")
            .setPositiveButton("Sí, cargué") { _, _ ->
                Estado.gncMetros = 0.0
                Estado.guardarGnc(this)
                actualizarPantalla()
            }
            .setNegativeButton("No", null)
            .show()
    }

    private fun un(decimal: Double): String {
        return String.format(Locale("es", "AR"), "%.1f", decimal)
    }

    private fun tiempoTexto(ms: Long): String {
        val minutos = ms / 60000L
        val resto = (minutos % 60L).toString().padStart(2, '0')
        return (minutos / 60L).toString() + ":" + resto
    }

    // ---------- Velocímetro ----------

    private fun pedirPermisoYArrancar() {
        if (Estado.gpsActivo) return
        if (Build.VERSION.SDK_INT >= 23 &&
            checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), PEDIDO_UBICACION)
        } else {
            arrancarServicio()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PEDIDO_UBICACION &&
            grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            arrancarServicio()
        }
    }

    private fun arrancarServicio() {
        val intento = Intent(this, SpeedService::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(intento)
        } else {
            startService(intento)
        }
    }

    private fun ajustes() = getSharedPreferences("ajustes", Context.MODE_PRIVATE)

    private fun cambiarLimite(cambio: Int) {
        val nuevo = (ajustes().getInt("limite", 60) + cambio).coerceIn(20, 200)
        ajustes().edit().putInt("limite", nuevo).apply()
        actualizarPantalla()
    }

    private fun alternarAlarma() {
        val activa = ajustes().getBoolean("alarma", true)
        ajustes().edit().putBoolean("alarma", !activa).apply()
        actualizarPantalla()
    }

    private fun actualizarPantalla() {
        val ahora = SystemClock.elapsedRealtime()
        val conSenal = Estado.gpsActivo && ahora - Estado.ultimaMedicion < 5000L
        velocidad.text = if (conSenal) Estado.velocidad.toString() else "--"
        velocidad.setTextColor(
            if (conSenal && Estado.excedido) Color.parseColor("#FF3B30") else Color.WHITE
        )
        gps.text = when {
            !Estado.gpsActivo -> "GPS apagado: falta el permiso de ubicación"
            !conSenal -> "Buscando señal de GPS…"
            else -> "GPS conectado"
        }
        limiteTxt.text = "Límite " + ajustes().getInt("limite", 60)
        alarmaBtn.text = if (ajustes().getBoolean("alarma", true)) "Alarma: sí" else "Alarma: no"

        // Viaje
        val km = Estado.viajeMetros / 1000.0
        viajeKm.text = un(km)
        viajeTiempo.text = tiempoTexto(Estado.viajeMs)
        viajeMedia.text = if (Estado.viajeMs > 0L) {
            Math.round(km / (Estado.viajeMs / 3600000.0)).toString()
        } else {
            "0"
        }
        viajeMax.text = Estado.velMax.toString()

        // GNC
        val autonomia = ajustes().getInt("gnc_auton", 220)
        val recorrido = Estado.gncMetros / 1000.0
        val resta = (autonomia - recorrido).coerceAtLeast(0.0)
        gncRestante.text = Math.round(resta).toString() + " km"
        gncRestante.setTextColor(if (resta <= RESERVA_KM) Color.parseColor("#FF3B30") else Color.WHITE)
        gncBarra.progress = if (autonomia > 0) Math.round(resta / autonomia * 100.0).toInt() else 0
        gncDetalle.text = "Recorridos " + Math.round(recorrido) + " km desde la carga"
        gncAuton.text = "Tubo lleno: $autonomia km"

        mostrarClima()
        revisarClima()
    }

    // ---------- Saludo ----------

    private fun idGrabacion(): Int {
        val nombre = when (saludo) {
            "Buenos días" -> "saludo_dias"
            "Buenas tardes" -> "saludo_tardes"
            else -> "saludo_noches"
        }
        return resources.getIdentifier(nombre, "raw", packageName)
    }

    private fun reproducirGrabacion(id: Int) {
        try {
            val reproductor = MediaPlayer.create(this, id) ?: return
            reproductor.setOnCompletionListener { it.release() }
            reproductor.start()
            estadoVoz.text = "Saludo grabado"
        } catch (e: Exception) {
        }
    }

    private fun repetirSaludo() {
        val grabacion = idGrabacion()
        if (grabacion != 0) reproducirGrabacion(grabacion) else decirSaludo()
    }

    override fun onInit(status: Int) {
        val voz = tts ?: return
        if (status != TextToSpeech.SUCCESS) {
            estadoVoz.text = "Sin motor de voz"
            return
        }

        var resultado = voz.setLanguage(Locale("es", "AR"))
        if (sinIdioma(resultado)) resultado = voz.setLanguage(Locale("es", "ES"))
        if (sinIdioma(resultado)) resultado = voz.setLanguage(Locale("es"))
        if (sinIdioma(resultado)) {
            estadoVoz.text = "Sin voz en español"
            return
        }

        vozLista = true
        estadoVoz.text = "Voz lista a los " + segundos() + " s"

        voz.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                val texto = "Saludo dicho a los " + segundos() + " s"
                runOnUiThread { estadoVoz.text = texto }
            }

            override fun onDone(utteranceId: String?) {}

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {}
        })

        handler.postDelayed({ decirSaludo() }, ESPERA_MS)
    }

    private fun segundos(): String {
        val s = (SystemClock.elapsedRealtime() - inicio) / 100L
        return (s / 10L).toString() + "." + (s % 10L).toString()
    }

    private fun decirSaludo() {
        if (!vozLista) return
        tts?.speak("$saludo, $NOMBRE", TextToSpeech.QUEUE_FLUSH, null, "saludo")
    }

    private fun sinIdioma(resultado: Int): Boolean {
        return resultado == TextToSpeech.LANG_MISSING_DATA ||
            resultado == TextToSpeech.LANG_NOT_SUPPORTED
    }

    private fun saludoPorHora(): String {
        val hora = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when (hora) {
            in 6..11 -> "Buenos días"
            in 12..19 -> "Buenas tardes"
            else -> "Buenas noches"
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        tts?.shutdown()
        super.onDestroy()
    }

    companion object {
        const val NOMBRE = "Elias"
        const val ESPERA_MS = 300L
        const val PEDIDO_UBICACION = 10
        const val RESERVA_KM = 30.0
        var yaSaludo = false
        var lucesEncendidas = false
    }
}

private class AppInfo(val nombre: String, val paquete: String, val icono: Drawable)
