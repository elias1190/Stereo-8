package com.elias.stereo

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Button
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private val handler = Handler(Looper.getMainLooper())
    private val inicio = SystemClock.elapsedRealtime()
    private var saludo = ""
    private var vozLista = false

    private lateinit var velocidad: TextView
    private lateinit var gps: TextView
    private lateinit var limiteTxt: TextView
    private lateinit var alarmaBtn: Button
    private lateinit var estadoVoz: TextView

    private val refrescar = object : Runnable {
        override fun run() {
            actualizarPantalla()
            handler.postDelayed(this, 500L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        velocidad = findViewById<TextView>(R.id.velocidad)
        gps = findViewById<TextView>(R.id.gps)
        limiteTxt = findViewById<TextView>(R.id.limite)
        alarmaBtn = findViewById<Button>(R.id.alarma)
        estadoVoz = findViewById<TextView>(R.id.estadoVoz)

        saludo = saludoPorHora()
        val hola = findViewById<TextView>(R.id.hola)
        hola.text = "Hola, $NOMBRE"
        findViewById<TextView>(R.id.saludo).text = "$saludo · Bienvenido"
        hola.setOnClickListener { decirSaludo() }

        findViewById<Button>(R.id.menos).setOnClickListener { cambiarLimite(-5) }
        findViewById<Button>(R.id.mas).setOnClickListener { cambiarLimite(5) }
        alarmaBtn.setOnClickListener { alternarAlarma() }

        // El saludo por voz suena una sola vez por cada arranque de la app
        if (!yaSaludo) {
            yaSaludo = true
            estadoVoz.text = "Iniciando la voz…"
            tts = TextToSpeech(this, this)
        }
    }

    override fun onResume() {
        super.onResume()
        val formato = SimpleDateFormat("EEEE, d 'de' MMMM", Locale("es", "AR"))
        findViewById<TextView>(R.id.fecha).text = formato.format(Date())
        handler.post(refrescar)
        pedirPermisoYArrancar()
    }

    override fun onPause() {
        handler.removeCallbacks(refrescar)
        super.onPause()
    }

    // ---------- Velocímetro ----------

    private fun pedirPermisoYArrancar() {
        if (Estado.gpsActivo) return
        if (Build.VERSION.SDK_INT >= 23 &&
            checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), PEDIDO_UBICACION)
        } else {
            arrancarServicio()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PEDIDO_UBICACION &&
            grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            arrancarServicio()
        }
    }

    private fun arrancarServicio() {
        val intento = Intent(this, SpeedService::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(intento)
        } else {
            startService(intento)
        }
    }

    private fun ajustes() = getSharedPreferences("ajustes", Context.MODE_PRIVATE)

    private fun cambiarLimite(cambio: Int) {
        val nuevo = (ajustes().getInt("limite", 60) + cambio).coerceIn(20, 200)
        ajustes().edit().putInt("limite", nuevo).apply()
        actualizarPantalla()
    }

    private fun alternarAlarma() {
        val activa = ajustes().getBoolean("alarma", true)
        ajustes().edit().putBoolean("alarma", !activa).apply()
        actualizarPantalla()
    }

    private fun actualizarPantalla() {
        val ahora = SystemClock.elapsedRealtime()
        val conSenal = Estado.gpsActivo && ahora - Estado.ultimaMedicion < 5000L
        velocidad.text = if (conSenal) Estado.velocidad.toString() else "--"
        velocidad.setTextColor(
            if (conSenal && Estado.excedido) Color.parseColor("#FF3B30") else Color.WHITE
        )
        gps.text = when {
            !Estado.gpsActivo -> "GPS apagado: falta el permiso de ubicación"
            !conSenal -> "Buscando señal de GPS…"
            else -> "GPS conectado"
        }
        limiteTxt.text = "Límite " + ajustes().getInt("limite", 60)
        alarmaBtn.text = if (ajustes().getBoolean("alarma", true)) "Alarma: sí" else "Alarma: no"
    }

    // ---------- Saludo por voz ----------

    override fun onInit(status: Int) {
        val voz = tts ?: return
        if (status != TextToSpeech.SUCCESS) {
            estadoVoz.text = "Sin motor de voz"
            return
        }

        var resultado = voz.setLanguage(Locale("es", "AR"))
        if (sinIdioma(resultado)) resultado = voz.setLanguage(Locale("es", "ES"))
        if (sinIdioma(resultado)) resultado = voz.setLanguage(Locale("es"))
        if (sinIdioma(resultado)) {
            estadoVoz.text = "Sin voz en español"
            return
        }

        vozLista = true
        estadoVoz.text = "Voz lista a los " + segundos() + " s"

        voz.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                val texto = "Saludo dicho a los " + segundos() + " s"
                runOnUiThread { estadoVoz.text = texto }
            }

            override fun onDone(utteranceId: String?) {}

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {}
        })

        handler.postDelayed({ decirSaludo() }, ESPERA_MS)
    }

    private fun segundos(): String {
        val s = (SystemClock.elapsedRealtime() - inicio) / 100L
        return (s / 10L).toString() + "." + (s % 10L).toString()
    }

    private fun decirSaludo() {
        if (!vozLista) return
        tts?.speak("$saludo, $NOMBRE", TextToSpeech.QUEUE_FLUSH, null, "saludo")
    }

    private fun sinIdioma(resultado: Int): Boolean {
        return resultado == TextToSpeech.LANG_MISSING_DATA ||
            resultado == TextToSpeech.LANG_NOT_SUPPORTED
    }

    private fun saludoPorHora(): String {
        val hora = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when (hora) {
            in 6..11 -> "Buenos días"
            in 12..19 -> "Buenas tardes"
            else -> "Buenas noches"
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        tts?.shutdown()
        super.onDestroy()
    }

    companion object {
        const val NOMBRE = "Elias"
        const val ESPERA_MS = 300L
        const val PEDIDO_UBICACION = 10
        var yaSaludo = false
    }
}
