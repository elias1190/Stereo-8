package com.elias.stereo

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView

// Elegir el sonido de la alarma de velocidad y su volumen
class AlarmaActivity : Activity() {

    private lateinit var lista: LinearLayout
    private lateinit var barra: ProgressBar
    private lateinit var volumenTxt: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_alarma)
        Tema.aplicar(findViewById<View>(android.R.id.content), this)

        lista = findViewById<LinearLayout>(R.id.alLista)
        barra = findViewById<ProgressBar>(R.id.alBarra)
        volumenTxt = findViewById<TextView>(R.id.alVolTxt)

        findViewById<Button>(R.id.alVolver).setOnClickListener { finish() }
        findViewById<Button>(R.id.alMenos).setOnClickListener { cambiarVolumen(-10) }
        findViewById<Button>(R.id.alMas).setOnClickListener { cambiarVolumen(10) }
        findViewById<Button>(R.id.alProbar).setOnClickListener { probar() }

        armarLista()
        mostrarVolumen()
    }

    private fun ajustes() = getSharedPreferences("ajustes", Context.MODE_PRIVATE)

    private fun dp(valor: Int): Int = (valor * resources.displayMetrics.density).toInt()

    private fun armarLista() {
        lista.removeAllViews()
        val elegido = ajustes().getInt("alarma_sonido", 0)
        val acento = Tema.acento(this)
        for ((i, nombre) in SonidosAlarma.NOMBRES.withIndex()) {
            val boton = Button(this)
            boton.text = nombre
            boton.setAllCaps(false)
            boton.setTextColor(Color.WHITE)
            boton.textSize = 20f
            boton.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
            boton.gravity = android.view.Gravity.CENTER_VERTICAL or android.view.Gravity.START
            boton.setPadding(dp(20), 0, dp(20), 0)
            val fondo = GradientDrawable()
            fondo.setColor(if (i == elegido) acento else 0xFF2E2E36.toInt())
            fondo.cornerRadius = dp(12).toFloat()
            boton.background = fondo
            val medidas = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(52))
            medidas.bottomMargin = dp(8)
            boton.layoutParams = medidas
            boton.setOnClickListener {
                ajustes().edit().putInt("alarma_sonido", i).apply()
                armarLista()
                probar()
            }
            lista.addView(boton)
        }
    }

    private fun volumen(): Int = ajustes().getInt("alarma_volumen", 100)

    private fun mostrarVolumen() {
        volumenTxt.text = volumen().toString() + "%"
        barra.progress = volumen()
    }

    private fun cambiarVolumen(cambio: Int) {
        val nuevo = (volumen() + cambio).coerceIn(10, 100)
        ajustes().edit().putInt("alarma_volumen", nuevo).apply()
        mostrarVolumen()
        probar()
    }

    private fun probar() {
        SonidosAlarma.reproducir(ajustes().getInt("alarma_sonido", 0), volumen())
    }
}
