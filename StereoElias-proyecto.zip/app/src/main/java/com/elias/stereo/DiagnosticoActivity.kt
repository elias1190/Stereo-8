package com.elias.stereo

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.service.notification.StatusBarNotification
import android.view.View
import android.widget.Button
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TreeSet
import java.util.zip.ZipFile
import org.xmlpull.v1.XmlPullParser

// Pantalla de pruebas: averigua qué se puede controlar en este stereo (radio, Sygic, voz)
class DiagnosticoActivity : Activity() {

    private lateinit var texto: TextView
    private lateinit var scroll: ScrollView
    private var registrado = false

    private val receptor = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent == null) return
            val sb = StringBuilder(hora() + " RECIBIDO " + intent.action)
            val extras = intent.extras
            if (extras != null) {
                for (clave in extras.keySet()) {
                    sb.append("\n      ").append(clave).append(" = ").append(extras.get(clave))
                }
            }
            agregar(sb.toString())
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_diagnostico)
        Tema.aplicar(findViewById<View>(android.R.id.content), this)
        texto = findViewById<TextView>(R.id.diagTexto)
        scroll = findViewById<ScrollView>(R.id.diagScroll)

        findViewById<Button>(R.id.diagVolver).setOnClickListener { finish() }
        findViewById<Button>(R.id.diagRadio).setOnClickListener { analizarRadio() }
        findViewById<Button>(R.id.diagNotif).setOnClickListener { verNotificaciones() }
        findViewById<Button>(R.id.diagLimpiar).setOnClickListener { texto.text = "" }

        agregar("Pruebas del stereo. Toca los botones de arriba.")
        agregar("1) Leer la radio: busca cómo se controla la app de radio.")
        agregar("2) Notificaciones: muestra lo que publican la radio y Sygic.")
    }

    private fun hora(): String = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())

    private fun agregar(linea: String) {
        texto.append(linea + "\n")
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun paqueteRadio(): String {
        val guardado = getSharedPreferences("ajustes", Context.MODE_PRIVATE).getString("acc_Radio", null)
        return guardado ?: "com.acloud.stud.localradio"
    }

    // ---------- Radio ----------

    private fun analizarRadio() {
        val paquete = paqueteRadio()
        agregar("--- Leyendo la app de radio: " + paquete + " ---")
        Thread {
            val lineas = ArrayList<String>()
            val acciones = LinkedHashSet<String>()
            try {
                val recursos = packageManager.getResourcesForApplication(paquete)
                val lector = recursos.assets.openXmlResourceParser("AndroidManifest.xml")
                val ns = "http://schemas.android.com/apk/res/android"
                var tipo = lector.eventType
                while (tipo != XmlPullParser.END_DOCUMENT) {
                    if (tipo == XmlPullParser.START_TAG) {
                        val nombre = lector.name
                        if (nombre == "activity" || nombre == "service" || nombre == "receiver" || nombre == "provider") {
                            lineas.add(nombre + " " + (lector.getAttributeValue(ns, "name") ?: "?"))
                        } else if (nombre == "action") {
                            val accion = lector.getAttributeValue(ns, "name")
                            if (accion != null) {
                                lineas.add("      accion: " + accion)
                                acciones.add(accion)
                            }
                        }
                    }
                    tipo = lector.next()
                }
                lector.close()
            } catch (e: Exception) {
                lineas.add("No se pudo leer el manifiesto: " + e)
            }
            var candidatos: List<String> = emptyList()
            try {
                candidatos = buscarTextos(paquete)
            } catch (e: Exception) {
                lineas.add("No se pudo revisar el código: " + e)
            }
            runOnUiThread {
                for (l in lineas) agregar(l)
                agregar("--- Textos parecidos a acciones dentro de la app (" + candidatos.size + ") ---")
                for (c in candidatos) agregar(c)
                escuchar(acciones + candidatos)
            }
        }.start()
    }

    private fun buscarTextos(paquete: String): List<String> {
        val ruta = packageManager.getApplicationInfo(paquete, 0).sourceDir
        val hallados = TreeSet<String>()
        val patron = Regex("[A-Za-z][A-Za-z0-9_]*(?:\\.[A-Za-z0-9_]+){2,}")
        ZipFile(ruta).use { zip ->
            val entradas = zip.entries()
            while (entradas.hasMoreElements()) {
                val entrada = entradas.nextElement()
                if (entrada.name.startsWith("classes") && entrada.name.endsWith(".dex")) {
                    val bytes = zip.getInputStream(entrada).readBytes()
                    val todo = String(bytes, Charsets.ISO_8859_1)
                    for (m in patron.findAll(todo)) {
                        val t = m.value
                        val bajo = t.lowercase()
                        val sirve = bajo.contains("acloud") || bajo.contains("radio") ||
                            bajo.contains("freq") || bajo.contains("action")
                        val ruido = bajo.startsWith("java.") || bajo.startsWith("javax.") ||
                            bajo.startsWith("android.view") || bajo.startsWith("android.widget") ||
                            bajo.startsWith("android.os") || bajo.startsWith("kotlin") ||
                            bajo.startsWith("androidx") || bajo.startsWith("android.support") ||
                            bajo.startsWith("org.")
                        if (sirve && !ruido && t.length in 10..140) hallados.add(t)
                        if (hallados.size > 300) break
                    }
                }
            }
        }
        return hallados.toList()
    }

    private fun escuchar(acciones: Collection<String>) {
        if (registrado) {
            try {
                unregisterReceiver(receptor)
            } catch (e: Exception) {
            }
            registrado = false
        }
        val filtro = IntentFilter()
        var cuantas = 0
        for (a in acciones) {
            if (a.length in 6..150) {
                filtro.addAction(a)
                cuantas++
            }
        }
        if (cuantas > 0) {
            try {
                registerReceiver(receptor, filtro)
                registrado = true
            } catch (e: Exception) {
                agregar("No se pudo escuchar: " + e)
            }
        }
        agregar("--- Escuchando " + cuantas + " acciones. Abre la radio, cambia de emisora y vuelve aquí ---")
    }

    // ---------- Notificaciones ----------

    private fun describir(n: StatusBarNotification): String {
        val e = n.notification.extras
        val titulo = e.getCharSequence("android.title")
        val cuerpo = e.getCharSequence("android.text")
        val sub = e.getCharSequence("android.subText")
        val largo = e.getCharSequence("android.bigText")
        val sb = StringBuilder(n.packageName)
        sb.append(" | ").append(titulo ?: "").append(" | ").append(cuerpo ?: "")
        if (sub != null) sb.append(" | ").append(sub)
        if (largo != null) sb.append(" | ").append(largo)
        return sb.toString()
    }

    private fun verNotificaciones() {
        agregar("--- Notificaciones activas ---")
        val escucha = MusicListener.instancia
        if (escucha == null) {
            agregar("Falta activar el acceso a notificaciones para Stereo Elias.")
            return
        }
        try {
            val lista = escucha.activeNotifications
            if (lista == null || lista.isEmpty()) agregar("(no hay ninguna)")
            if (lista != null) {
                for (n in lista) agregar(describir(n))
            }
        } catch (e: Exception) {
            agregar("No se pudieron leer: " + e)
        }
    }

    override fun onDestroy() {
        if (registrado) {
            try {
                unregisterReceiver(receptor)
            } catch (e: Exception) {
            }
        }
        super.onDestroy()
    }

}
