package com.elias.stereo

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar

// Color principal de la interfaz: se puede cambiar cuando quieras desde Ajustes
object Tema {

    val PALETA: Array<Pair<String, Int>> = arrayOf(
        Pair("Rojo", 0xFFE10600.toInt()),
        Pair("Azul", 0xFF2D7BFF.toInt()),
        Pair("Celeste", 0xFF19B5FF.toInt()),
        Pair("Verde", 0xFF1FBF5B.toInt()),
        Pair("Naranja", 0xFFFF7A00.toInt()),
        Pair("Violeta", 0xFF8A4DFF.toInt())
    )

    fun indice(contexto: Context): Int {
        val guardado = contexto.getSharedPreferences("ajustes", Context.MODE_PRIVATE).getInt("tema", 0)
        return guardado.coerceIn(0, PALETA.size - 1)
    }

    fun acento(contexto: Context): Int = PALETA[indice(contexto)].second

    private fun forma(color: Int, d: Float, izqArriba: Int, derArriba: Int, izqAbajo: Int, derAbajo: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        val ia = izqArriba * d
        val da = derArriba * d
        val ib = izqAbajo * d
        val db = derAbajo * d
        g.cornerRadii = floatArrayOf(ia, ia, da, da, db, db, ib, ib)
        return g
    }

    private fun conBorde(acento: Int, fondo: Int, d: Float, ia: Int, da: Int, ib: Int, db: Int): LayerDrawable {
        val capas = LayerDrawable(arrayOf(forma(acento, d, ia, da, ib, db), forma(fondo, d, ia, da, ib, db)))
        capas.setLayerInset(1, 0, (3 * d).toInt(), 0, 0)
        return capas
    }

    // Recorre las vistas y les pone el color elegido según su etiqueta (tag)
    fun aplicar(vista: View, contexto: Context) {
        aplicarEn(vista, acento(contexto), contexto.resources.displayMetrics.density)
    }

    private fun aplicarEn(vista: View, color: Int, d: Float) {
        when (vista.tag) {
            "tarjeta" -> vista.background = conBorde(color, 0xFF17171C.toInt(), d, 6, 28, 6, 28)
            "boton" -> vista.background = conBorde(color, 0xFF26262E.toInt(), d, 4, 16, 4, 16)
            "menu" -> vista.background = forma(color, d, 4, 22, 22, 4)
            "bola" -> {
                val g = GradientDrawable()
                g.shape = GradientDrawable.OVAL
                g.setColor(0xFF17171C.toInt())
                g.setStroke((3 * d).toInt(), color)
                vista.background = g
            }
            "barra" -> {
                if (vista is ProgressBar) vista.progressTintList = ColorStateList.valueOf(color)
            }
        }
        if (vista is ViewGroup) {
            for (i in 0 until vista.childCount) {
                aplicarEn(vista.getChildAt(i), color, d)
            }
        }
    }
}
