package com.elias.stereo

import android.service.notification.NotificationListenerService

// No hace nada por sí mismo: sirve para que Android permita leer el reproductor de música activo
class MusicListener : NotificationListenerService()
