package com.elias.stereo

import android.service.notification.NotificationListenerService

// Sirve para que Android permita leer el reproductor de música activo y las notificaciones
class MusicListener : NotificationListenerService() {

    override fun onListenerConnected() {
        instancia = this
    }

    override fun onListenerDisconnected() {
        if (instancia === this) instancia = null
    }

    companion object {
        @Volatile
        var instancia: MusicListener? = null
    }
}
