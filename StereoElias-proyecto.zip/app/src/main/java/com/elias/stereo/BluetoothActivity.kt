package com.elias.stereo

import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.widget.Button
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast

// Pantalla de Bluetooth: lo que suena, la barra de avance y los dispositivos emparejados
class BluetoothActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())
    private var controlador: MediaController? = null

    private lateinit var titulo: TextView
    private lateinit var artista: TextView
    private lateinit var barra: ProgressBar
    private lateinit var actual: TextView
    private lateinit var total: TextView
    private lateinit var play: ImageButton
    private lateinit var estado: TextView

    private val ciclo = object : Runnable {
        override fun run() {
            try {
                actualizar()
            } catch (e: Exception) {
            }
            handler.postDelayed(this, 500L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bluetooth)

        titulo = findViewById<TextView>(R.id.btTitulo)
        artista = findViewById<TextView>(R.id.btArtista)
        barra = findViewById<ProgressBar>(R.id.btBarra)
        actual = findViewById<TextView>(R.id.btActual)
        total = findViewById<TextView>(R.id.btTotal)
        play = findViewById<ImageButton>(R.id.btPlay)
        estado = findViewById<TextView>(R.id.btEstado)

        findViewById<Button>(R.id.btVolver).setOnClickListener { finish() }
        findViewById<ImageButton>(R.id.btPrev).setOnClickListener { controlar(-1) }
        play.setOnClickListener { controlar(0) }
        findViewById<ImageButton>(R.id.btNext).setOnClickListener { controlar(1) }

        findViewById<Button>(R.id.btAjustes).setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
            } catch (e: Exception) {
                Toast.makeText(this, "Este stereo no trae esa pantalla", Toast.LENGTH_SHORT).show()
            }
        }
        findViewById<Button>(R.id.btApp).setOnClickListener { abrirAppDelStereo() }

        llenarDispositivos()
    }

    override fun onResume() {
        super.onResume()
        Estado.pantallaPropia = true
        handler.post(ciclo)
    }

    override fun onPause() {
        Estado.pantallaPropia = false
        handler.removeCallbacks(ciclo)
        super.onPause()
    }

    private fun abrirAppDelStereo() {
        val paquete = getSharedPreferences("ajustes", Context.MODE_PRIVATE).getString("acc_Música", null)
        val intento = if (paquete != null) packageManager.getLaunchIntentForPackage(paquete) else null
        if (intento != null) {
            try {
                startActivity(intento)
            } catch (e: Exception) {
            }
        } else {
            Toast.makeText(
                this,
                "Primero elige esa app: en la pantalla principal, mantén apretado el título de la música",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun llenarDispositivos() {
        val lista = findViewById<LinearLayout>(R.id.btLista)
        lista.removeAllViews()
        val nombres = ArrayList<String>()
        try {
            val adaptador = BluetoothAdapter.getDefaultAdapter()
            val emparejados = adaptador?.bondedDevices
            if (emparejados != null) {
                for (d in emparejados) {
                    nombres.add(d.name ?: d.address)
                }
            }
        } catch (e: Exception) {
        }
        if (nombres.isEmpty()) nombres.add("No hay dispositivos emparejados")
        for (nombre in nombres.take(6)) {
            val fila = TextView(this)
            fila.text = nombre
            fila.setTextColor(0xFFFFFFFF.toInt())
            fila.textSize = 20f
            fila.typeface = android.graphics.Typeface.create("sans-serif-condensed", android.graphics.Typeface.BOLD)
            fila.setPadding(0, 10, 0, 10)
            fila.maxLines = 1
            lista.addView(fila)
        }
    }

    private fun buscar(): MediaController? {
        return try {
            val lista = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
            if (lista == null || !lista.contains(packageName)) {
                null
            } else {
                val gestor = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
                val sesiones = gestor.getActiveSessions(ComponentName(this, MusicListener::class.java))
                sesiones.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
                    ?: sesiones.firstOrNull()
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun controlar(accion: Int) {
        val c = controlador ?: return
        try {
            when (accion) {
                -1 -> c.transportControls.skipToPrevious()
                1 -> c.transportControls.skipToNext()
                else -> {
                    if (c.playbackState?.state == PlaybackState.STATE_PLAYING) {
                        c.transportControls.pause()
                    } else {
                        c.transportControls.play()
                    }
                }
            }
        } catch (e: Exception) {
        }
    }

    private fun tiempo(ms: Long): String {
        val s = ms / 1000L
        return (s / 60L).toString() + ":" + (s % 60L).toString().padStart(2, '0')
    }

    private fun actualizar() {
        val c = buscar()
        controlador = c
        if (c == null) {
            titulo.text = "Sin música activa"
            artista.text = "Pon música por Bluetooth desde el celular"
            barra.progress = 0
            actual.text = "--:--"
            total.text = "--:--"
            play.setImageResource(R.drawable.ic_play)
            estado.text = "Sin reproductor"
            return
        }
        val datos = c.metadata
        titulo.text = datos?.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: datos?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
            ?: "Sin título"
        artista.text = datos?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""

        val situacion = c.playbackState
        val sonando = situacion?.state == PlaybackState.STATE_PLAYING
        play.setImageResource(if (sonando) R.drawable.ic_pause else R.drawable.ic_play)
        estado.text = if (sonando) "Sonando" else "En pausa"

        val duracion = datos?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
        var posicion = situacion?.position ?: -1L
        if (sonando && situacion != null && posicion >= 0L) {
            val pasado = SystemClock.elapsedRealtime() - situacion.lastPositionUpdateTime
            posicion += (pasado * situacion.playbackSpeed).toLong()
        }
        actual.text = if (posicion >= 0L) tiempo(posicion) else "--:--"
        if (duracion > 0L) {
            total.text = tiempo(duracion)
            val avance = if (posicion < 0L) 0L else posicion.coerceIn(0L, duracion)
            barra.progress = (avance * 1000L / duracion).toInt()
        } else {
            total.text = "--:--"
            barra.progress = 0
        }
    }
}
