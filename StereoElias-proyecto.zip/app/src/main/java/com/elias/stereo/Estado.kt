package com.elias.stereo

import android.content.Context

// Datos compartidos entre el servicio del GPS y la pantalla
object Estado {
    @Volatile var velocidad: Int = 0
    @Volatile var ultimaMedicion: Long = 0L
    @Volatile var gpsActivo: Boolean = false
    @Volatile var excedido: Boolean = false
    @Volatile var pantallaPropia: Boolean = false
    @Volatile var pantallaPrincipal: Boolean = false

    // Ubicación y clima
    @Volatile var latitud: Double = 0.0
    @Volatile var longitud: Double = 0.0
    @Volatile var climaOk: Boolean = false
    @Volatile var climaTemp: Int = 0
    @Volatile var climaMax: Int = 0
    @Volatile var climaMin: Int = 0
    @Volatile var climaHumedad: Int = 0
    @Volatile var climaViento: Int = 0
    @Volatile var climaCodigo: Int = 0

    // Viaje (se reinicia con el botón o al reiniciar la app)
    @Volatile var velMax: Int = 0
    @Volatile var viajeMetros: Double = 0.0
    @Volatile var viajeMs: Long = 0L

    // Recorrido desde la última carga de GNC (se guarda en el teléfono)
    @Volatile var gncMetros: Double = 0.0

    private var cargado = false

    fun cargar(contexto: Context) {
        if (cargado) return
        cargado = true
        val prefs = contexto.getSharedPreferences("ajustes", Context.MODE_PRIVATE)
        gncMetros = prefs.getFloat("gnc_m", 0f).toDouble()
    }

    fun guardarGnc(contexto: Context) {
        val prefs = contexto.getSharedPreferences("ajustes", Context.MODE_PRIVATE)
        prefs.edit().putFloat("gnc_m", gncMetros.toFloat()).apply()
    }

    fun reiniciarViaje() {
        velMax = 0
        viajeMetros = 0.0
        viajeMs = 0L
    }
}

// Algunos celulares mandan "Not Provided" cuando no informan el título: se trata como vacío
fun textoLimpio(texto: String?): String? {
    if (texto == null) return null
    val t = texto.trim()
    if (t.isEmpty()) return null
    if (t.equals("Not Provided", ignoreCase = true)) return null
    if (t.equals("<unknown>", ignoreCase = true)) return null
    return t
}
