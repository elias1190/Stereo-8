package com.elias.stereo

import android.content.Context

// Datos compartidos entre el servicio del GPS y la pantalla
object Estado {
    @Volatile var velocidad: Int = 0
    @Volatile var ultimaMedicion: Long = 0L
    @Volatile var gpsActivo: Boolean = false
    @Volatile var excedido: Boolean = false
    @Volatile var pantallaPropia: Boolean = false

    // Viaje (se reinicia con el botón o al reiniciar la app)
    @Volatile var velMax: Int = 0
    @Volatile var viajeMetros: Double = 0.0
    @Volatile var viajeMs: Long = 0L

    // Recorrido desde la última carga de GNC (se guarda en el teléfono)
    @Volatile var gncMetros: Double = 0.0

    private var cargado = false

    fun cargar(contexto: Context) {
        if (cargado) return
        cargado = true
        val prefs = contexto.getSharedPreferences("ajustes", Context.MODE_PRIVATE)
        gncMetros = prefs.getFloat("gnc_m", 0f).toDouble()
    }

    fun guardarGnc(contexto: Context) {
        val prefs = contexto.getSharedPreferences("ajustes", Context.MODE_PRIVATE)
        prefs.edit().putFloat("gnc_m", gncMetros.toFloat()).apply()
    }

    fun reiniciarViaje() {
        velMax = 0
        viajeMetros = 0.0
        viajeMs = 0L
    }
}
