package com.elias.stereo

// Datos compartidos entre el servicio del GPS y la pantalla
object Estado {
    @Volatile var velocidad: Int = 0
    @Volatile var ultimaMedicion: Long = 0L
    @Volatile var gpsActivo: Boolean = false
    @Volatile var excedido: Boolean = false
}
